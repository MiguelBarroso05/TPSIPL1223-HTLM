<?php 

	include 'modules/head.php';
	include 'modules/header.php';
	include 'modules/nav.php';
	include 'modules/main.php';
	include 'modules/footer.php';

?>