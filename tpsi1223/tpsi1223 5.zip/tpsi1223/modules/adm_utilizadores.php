<div class="d-flex flex-row">
	<div class="col-lg-12 col-sm-12">
		<table>
			<thead>
				<th>Nome:</th>
				<th>Sobrenome:</th>
				<th>Email:</th>
				<th>Perfil:</th>
				<th></th>
			</thead>
			<tbody>
				<?php function_lista_utilizadores(); ?>
			</tbody>
		</table>
	</div>
</div>