<nav>
	
	<ul>
		<?php menu(); ?>
	</ul>

</nav>