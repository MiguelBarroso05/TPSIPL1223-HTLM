Cria num novo diretorio (teste2)

- Particiona o esqueleto de um doc html standard por 5 ficheiros php
- Usa o teu index.php para incluir os 5 php

- em Nav.php 
	cria uma lista com links que passe os valores (quem, servicos, produtos, contactos) para a url

- em main.php
	cria um switch que leia a opção de nav
	faz eco ao conteúdo de cada opção com o seu respetivo nome

- adiciona à lista de nav um menu login (login)
- adiciona ao switch o momento login e apresenta um form com email e pass 

- ao fazer login regista na sessao o email do user

- no caso de existir login em nav.php troca o menu login por logout e liga o logout ao ficheiro sair.php(reaproveita do teste)


