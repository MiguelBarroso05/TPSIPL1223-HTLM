<section>
	<div class="home_top_banner"></div>
</section>
<section>
	<h3>Sobre Nós</h3>
	<div class="d-flex flex-row">
		<div class="col-lg-6 col-sm-6">
			Foto
		</div>
		<div class="col-lg-6 col-sm-6">
			Bla
		</div>
	</div>
</section>
<section>
	<h3>Top Sellers</h3>
	....
</section>
