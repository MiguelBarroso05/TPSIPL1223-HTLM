<?php

//acesso à sessão
session_start();
//Indice de funções 

include 'functions/function_login.php';
include 'functions/function_registo.php';
include 'functions/function_nova_categoria.php';
include 'functions/function_lista_categorias.php';
include 'functions/function_delete_categoria.php';
include 'functions/function_edit_categoria.php';
include 'functions/function_lista_utilizadores.php';

include 'functions/function_institucional.php';
include 'functions/function_form_institucional.php';


?>